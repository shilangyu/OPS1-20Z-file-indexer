/*
------------------------------------------------------------------------
I declare that this piece of work which is the basis for recognition of
achieving learning outcomes in the OPS1 course was completed on my own.
Marcin Wojnarowski, 303880
------------------------------------------------------------------------
*/

#include <math.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define ERR(source)                                                \
  (perror(source), fprintf(stderr, "%s:%d\n", __FILE__, __LINE__), \
   exit(EXIT_FAILURE))

void* worker(void* args) {
  printf("[%ld] Hi!\n", pthread_self());
  sleep(1);
  printf("[%ld] Bye!\n", pthread_self());

  return NULL;
}

void help(int argc, char** argv) {
  printf("USAGE: %s <n> <m> <k>\n", argv[0]);
  printf("\tn, m - [1, 100]\n");
  printf("\tk - [3, 100]\n");
  exit(EXIT_FAILURE);
}

int main(int argc, char** argv) {
  // validate and load args
  if (argc != 4) {
    help(argc, argv);
  }
  int n = atoi(argv[1]);
  int m = atoi(argv[2]);
  int k = atoi(argv[3]);
  if (n < 1 || n > 100 || m < 1 || m > 100 || k < 3 || k > 100)
    help(argc, argv);

  // start threads
  pthread_t pthid[k];
  for (size_t i = 0; i < k; i++) {
    if (pthread_create(&pthid[i], NULL, worker, NULL))
      ERR("pthread_create");
  }

  // wait for all threads
  for (size_t i = 0; i < k; i++) {
    if (pthread_join(pthid[i], NULL))
      ERR("pthread_join");
  }

  return EXIT_SUCCESS;
}
