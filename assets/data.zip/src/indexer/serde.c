#define _XOPEN_SOURCE 500
#include "../cmd/cmd.h"
#include "../main.h"
#include "./indexer.h"
#include <fcntl.h>
#include <ftw.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

index_file_type get_file_type(const char *filename, int type) {
    if (type == FTW_DNR || type == FTW_D) {
        return INDEX_FILE_TYPE_DIR;
    }

    // src: https://en.wikipedia.org/wiki/List_of_file_signatures
    static const uint8_t PNG_SIGNATURE[]      = {0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};
    static const uint8_t GZIP_SIGNATURE[]     = {0x1F, 0x8B};
    static const uint8_t ZIP_SIGNATURES[3][4] = {
        {0x50, 0x4B, 0x03, 0x04},
        {0x50, 0x4B, 0x05, 0x06},
        {0x50, 0x4B, 0x07, 0x08}};
    // TODO: wtf are ?? in file signature?
    static const uint8_t JPG_SIGNATURES[3][4] = {
        {0xFF, 0xD8, 0xFF, 0xDB},
        // {0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01},
        // {0xFF, 0xD8, 0xFF, 0xE1, 0x??, 0x??, 0x45, 0x78, 0x69, 0x66, 0x00, 0x00},
        {0xFF, 0xD8, 0xFF, 0xEE}};

    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        ERR("open");
    }

    // 12 because that is the longest signature
    static const size_t SIG_SIZE = 12;
    uint8_t buffer[SIG_SIZE];
    CHECK(read(fd, buffer, SIG_SIZE) == -1);

// helper for checking signatures
#define CHECK_SIGNATURE(signature, length, then_return) \
    do {                                                \
        bool is_that = true;                            \
        for (size_t i = 0; i < (length); i++) {         \
            if (buffer[i] != (signature)[i]) {          \
                is_that = false;                        \
                break;                                  \
            }                                           \
        }                                               \
        if (is_that) return (then_return);              \
    } while (0)

    CHECK_SIGNATURE(PNG_SIGNATURE, 8, INDEX_FILE_TYPE_PNG);
    CHECK_SIGNATURE(GZIP_SIGNATURE, 2, INDEX_FILE_TYPE_GZIP);

#undef CHECK_SIGNATURE

    CHECK(close(fd));

    return INDEX_FILE_TYPE_UNKNOWN;
}
